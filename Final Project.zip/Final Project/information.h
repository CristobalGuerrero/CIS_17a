/* 
 * File:   information.h
 * Author: Owner
 *
 * Created on June 4, 2010, 1:16 PM
 */

#ifndef _INFORMATION_H
#define	_INFORMATION_H
#include <string>
using namespace std;

class Information {
private:
    string Intro;
public:
    Information();
    void printinformation();
};


#endif	/* _INFORMATION_H */

