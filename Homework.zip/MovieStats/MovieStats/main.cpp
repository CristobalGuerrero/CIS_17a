/* 
 * File:   main.cpp
 * Author: rcc
 *
 * Created on March 11, 2010, 3:13 PM
 */

#include <stdlib.h>

/*
 * 
 */
int main(int argc, char** argv) {
    //ask user how many students were surveyed, array of ints dynamically allocated
    //allow the user to enter the number of movies for each student
    //calculate and display the average, median, and mode of the values entered
    //do not accept negative numbers
    return (EXIT_SUCCESS);
}

