/* 
 * File:   main.cpp
 * Author: rcc
 *
 * Created on March 11, 2010, 3:12 PM
 */

#include <stdlib.h>

/*
 * 
 */
int main(int argc, char** argv) {
    ////an array of integers
    //an integer that indicates the number of elements in the array
    //return number thats in the middle of the array
    return (EXIT_SUCCESS);
}

