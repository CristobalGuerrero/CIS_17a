/* 
 * File:   main.cpp
 * Author: rcc
 *
 * Created on March 11, 2010, 2:58 PM
 */

#include <stdlib.h>

/*
 * 
 */
int main(int argc, char** argv) {
    //wrtie a for loop that displays every fifth
    //number starting at zero through 100
    return (EXIT_SUCCESS);
}

