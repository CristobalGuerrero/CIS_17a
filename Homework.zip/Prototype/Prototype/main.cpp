/* 
 * File:   main.cpp
 * Author: rcc
 *
 * Created on March 11, 2010, 3:00 PM
 */

#include <stdlib.h>

/*
 * 
 */
int main(int argc, char** argv) {
    //write a prototype for the timesTen function
    //function passes in an integer perameter named number
    return (EXIT_SUCCESS);
}

