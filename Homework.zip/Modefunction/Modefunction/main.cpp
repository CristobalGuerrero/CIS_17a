/* 
 * File:   main.cpp
 * Author: rcc
 *
 * Created on March 11, 2010, 3:10 PM
 */

#include <stdlib.h>

/*
 * 
 */
int main(int argc, char** argv) {
    //the mode of a set of values is the value which occurs the most offten
    //write a function that accepts as arguments the following
    //an array of integers
    //an integer that indicates the fnumber of elements in the array
    //function should return the mode of the array
    return (EXIT_SUCCESS);
}

