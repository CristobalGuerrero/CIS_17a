/* 
 * File:   main.cpp
 * Author: rcc
 *
 * Created on March 11, 2010, 2:56 PM
 */

#include <stdlib.h>

/*
 * 
 */
int main(int argc, char** argv) {
    //Write an if statement tht assigns a .20 to
    //commisiion when sales is greater then or equal to 10k
    return (EXIT_SUCCESS);
}

