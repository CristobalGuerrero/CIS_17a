/* 
 * File:   main.cpp
 * Author: rcc
 *
 * Created on March 11, 2010, 3:02 PM
 */

#include <stdlib.h>

/*
 * 
 */
int main(int argc, char** argv) {
   //what is the following output of the program
    int value[5], count;
    for(count=0;count<5;count++)
        values[count]=count+1;
    for(count=0;count<5;count++)
        cout<<values[count]<<endl;
    return (EXIT_SUCCESS);
}

